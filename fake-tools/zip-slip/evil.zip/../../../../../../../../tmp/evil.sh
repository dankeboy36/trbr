#! /bin/sh

echo "evil"
